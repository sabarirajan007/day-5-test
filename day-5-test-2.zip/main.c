/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

struct student_mark_sheet {
  char name[30];
  int num;
};

int main() {
  struct student_mark_sheet stud1, stud2, stud3,stud4,stud5;

  printf("ENTER STUDENT ONE NAME ,MARK: ");
  scanf("%s %d",STUD1.NAME,&STUD1.MARK);

  printf("ENTER STUDENT TWO NAME ,MARK: ");
  scanf("%s %d",STUD2.NAME,&STUD2.MARK);

  printf("ENTER STUDENT THREE NAME ,MARK: ");
  scanf("%s %d", STUD3.NAME,&STUD3.MARK);
  
  printf("ENTER STUDENT FOUR NAME ,MARK: ");
  scanf("%s %d", STUD4.NAME,&STUD4.MARK);
  
  printf("ENTER STUDENT FIVE NAME ,MARK: ");
  scanf("%s %d", STUD5.NAME,&STUD5.MARK);


  printf("%s  %d\n", STUD1.NAME,STUD1.MARK);
  printf("%s  %d\n", STUD2.NAME,STUD2.MARK);
  printf("%s  %d\n", STUD3.NAME,STUD3.MARK);
  printf("%s  %d\n", STUD4.NAME,STUD4.MARK);
  printf("%s  %d\n", STUD5.NAME,STUD5.MARK);

  return 0;
}
